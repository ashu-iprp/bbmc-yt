# YT-Live-To-Discord
Quick and dirty, dead simple Node.js app that polls the YouTube Data API and will post notifications to Discord chats through Webhooks

Note:
This is in no way decoupled from the use case that I had. You will have to setup your own channel list to poll and the structure of the discord object to send to discord.
